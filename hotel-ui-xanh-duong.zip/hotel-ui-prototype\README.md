# Hotel Manager - UI Prototype

Ban HTML tinh de designer tham khao layout, mau sac, component.

## Cach mo

1. Giai nen thu muc
2. Mo file index.html bang Chrome / Edge
3. Click cac menu ben trai de xem cac trang khac

## Co gi

- Xem duoc: Tong quan, So do phong, Don thue, Chi tiet don, Thanh toan,
  Hoa don, Khach hang, Quan ly phong, Loai phong, Do dung, Bao cao,
  Lich su, Tai khoan, Vai tro, Backup, View mobile
- Khong hoat dong: gui form, submit, dang nhap - chi la giao dien tinh

## Cau truc

static/css/  - CSS
*.html       - moi file la 1 trang

## Component can thiet ke lai

1. Sidebar
2. So do phong - card vuong mau theo trang thai
3. Chi tiet booking - layout 3 cot
4. Bang du lieu
5. Modal doi phong
6. Form check-in
7. Hoa don A4
8. Mobile view
