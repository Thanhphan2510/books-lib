> <img src="./y24ovgoc.png"
> style="width:6.43125in;height:9.48694in" /><img src="./w4lheaak.png"
> style="width:1.39097in;height:1.53875in" />**HỌC** **VIỆN** **CÔNG**
> **NGHỆ** **BƯU** **CHÍNH** **VIỄN** **THÔNG**
>
> **KHOA** **ĐÀO** **TẠO** **SAU** **ĐẠI** **HỌC**
>
> **─────** ✦ **─────**
>
> **BÁO** **CÁO** **THỰC** **TẬP** **TỐT** **NGHIỆP**
>
> **Giảng** **viên** **hướng** **dẫn**
>
> **Học** **viên** **thực** **hiện**
>
> **Mã** **học** **viên**
>
> **Chuyên** **nghành**

**:** **TS.** **DƯƠNG** **TRẦN** **ĐỨC**

**:** **PHAN** **TIẾN** **THÀNH**

**:** **B25CHHT053**

**:** **Hệ** **thống** **thông** **tin**

> ***Hà*** ***Nội*** ***–*** ***2026***
>
> **LỜI** **CẢM** **ƠN**
>
> Lời đầu tiên, em xin được bày tỏ lòng biết ơn sâu sắc đến Ban Giám
> hiệu, Khoa Đào

tạo Sau Đại học cùng toàn thể các thầy cô giáo tại Học viện Công nghệ
Bưu chính Viễn

thông, những người đã truyền đạt cho em những kiến thức khoa học quý
báu, tạo nền tảng

lý thuyết vững chắc và tạo mọi điều kiện thuận lợi nhất cho em trong
suốt quá trình học tập và nghiên cứu hệ chương trình Thạc sĩ tại trường.

> Đặc biệt, em xin gửi lời cảm ơn chân thành và sâu sắc nhất tới Thầy
> TS. Dương Trần

Đức, người đã trực tiếp dành nhiều thời gian quý báu, tận tình chỉ bảo,
định hướng khoa

học và động viên em trong suốt quá trình lựa chọn, nghiên cứu và triển
khai đề tài thực tập

tiền đề này.

> Em cũng xin chân thành cảm ơn Ban Giám đốc cùng tập thể các kỹ sư,
> đồng nghiệp

tại Bộ phận Y thuộc Công Ty X. Sự hỗ trợ nhiệt tình, việc tạo điều kiện
cho em tiếp cận

với môi trường vận hành hạ tầng số thực tế, cũng như những kinh nghiệm
thực tiễn quý

báu từ các anh/chị đã giúp em hoàn thiện cấu trúc thuật toán và hoàn
thành tốt chương trình thực tập chuyên sâu này.

> Mặc dù đã có nhiều cố gắng, tập trung nghiên cứu và nghiêm túc triển
> khai, song do

giới hạn về thời gian và năng lực của bản thân, báo cáo thực tập này
chắc chắn không tránh

khỏi những thiếu sót. Em rất mong nhận được những ý kiến đóng góp, chỉ
dẫn quý báu của

các thầy cô giáo và các chuyên gia để đề tài nghiên cứu này được hoàn
thiện hơn, tạo tiền đề vững chắc cho việc thực hiện đồ án tốt nghiệp
Thạc sĩ trong giai đoạn kế tiếp.

> *Em* *xin* *chân* *thành* *cảm* *ơn!*
>
> **MỤC** **LỤC**

**DANH** **MỤC** **CÁC** **THUẬT** **NGỮ** **VÀ** **TỪ** **VIẾT**
**TẮT**.............................................................. 5
**DANH** **MỤC** **CÁC** **BẢNG** **BIỂU** **VÀ** **HÌNH**
**ẢNH**.....................................................................
7 **PHẦN** **1:** **THỰC** **TẬPTẠI** **CÔNG** **TY**
**X**....................................................................................
8 **1.1.** **Giới** **thiệu** **về** **Công**
**ty**....................................................................................................
8 **1.1.1.** **Một** **số** **thông** **tin** **về** **công** **ty**
.......................................................................8

> **1.1.2.** **Các** **sản** **phẩm** **của** **công**
> **ty**.........................................................................8
>
> **1.2.** **Nội** **dung** **thực** **tập** **tại** **công**
> **ty**.......................................................................................
> 8
>
> **1.2.1.** **Khái** **quát** **về** **Cloud** **Provider** **và**
> **bài** **toán** **giám** **sát** **hạ** **tầng** **số**
> ......................8
>
> **1.2.2.** **Thực** **trạng** **thị** **trường** **AIOps** **năm**
> **2026**.....................................................9
>
> **1.2.3.** **Nghiên** **cứu** **các** **thuật** **toán** **phát**
> **hiện** **bất** **thường** **tiên**
> **tiến**..........................10
>
> **1.2.3.1.**
>
> **1.2.3.2.**
>
> **1.2.3.3.**
>
> **1.2.3.4.**

**Isolation**
**Forest**............................................................................................
10

**Autoencoder**..................................................................................................11

**Mạng** **Long** **Short-Term** **Memory**
**(LSTM)**............................................... 12

**Mạng** **Temporal** **Convolutional** **Network** **(TCN)** **kết**
**hợpAttention**....... 13

> **1.2.4.** **Nghiên** **cứu** **kỹ** **thuật** **giảm** **nhiễu**
> **và** **gom** **cụm** **sự**
> **cố**...................................14
>
> **1.2.4.1.**
>
> **1.2.4.2.**

**Drain3**...........................................................................................................
14

**Thuật** **toán** **ST-DBSCAN** **(Gom** **cụm** **không** **-**
**thời** **gian)**.......................... 15

> **1.2.5.** **Nghiên** **cứu** **ứng** **dụng** **GenerativeAI**
> **(LLM** **&** **RAG)** ................................15
>
> **1.2.5.1.**
>
> **1.2.5.2.**

**Kiến** **trúc** **RAG** **(Retrieval-Augmented** **Generation)**
............................... 16

**Luồng** **suy** **luận** **CoT** **(Chain-of-Thought)** **cấu**
**trúc** **hóa** .......................... 16

**PHẦN** **2:** **THỰC** **TẬP** **CHUYÊN** **SÂU** **TẠI** **CÔNG**
**TY** .......................................................... 17

> **2.1.** **Tổng** **quan** **về** **hạ** **tầng** **thực**
> **nghiệm**...........................................................................
> 17
>
> **2.2.** **Xây** **dựng** **pipeline** **thu** **thập** **và** **mô**
> **phỏng** **dữ**
> **liệu**.................................................... 17
>
> **2.3.** **Cài** **đặt** **thuật** **toán** **và** **xây** **dựng**
> **AI**
> **Engine**...............................................................
> 19
>
> **2.3.1.** **Tiền** **xử** **lý** **dữ**
> **liệu**...................................................................................19
>
> **2.3.2.** **Xây** **dựng** **mô** **hình** **phát** **hiện** **bất**
> **thường** **(TCN** **+** **Attention** **+** **EVT)**...........20
>
> **2.3.3.** **Xây** **dựng** **module** **lọc** **Log** **và** **giảm**
> **nhiễu** **cảnh** **báo** **(Drain3** **&** **ST-DBSCAN)** 22
>
> **2.3.4.** **Xây** **dựng** **module** **phân** **tích** **nguyên**
> **nhân** **sử** **dụng** **LangChain** **và** **Ollama**..23
>
> **2.4.** **Thử** **nghiệm** **và** **đánh** **giá** **hiệu** **năng**
> **(Demo)**
> ............................................................. 25
>
> **2.4.1.** **Kịch** **bản** **thử**
> **nghiệm**..............................................................................................
> 25
>
> **2.4.2.** **Kết** **quả** **đánh**
> **giá**.....................................................................................................
> 25
>
> **2.4.3.** **Đánh**
> **giá**.........................................................................................................................
> 27

**KẾT**
**LUẬN**..................................................................................................................................
28

**TÀI** **LIỆU** **THAM**
**KHẢO**..........................................................................................................
29

> **DANH** **MỤC** **CÁC** **THUẬT** **NGỮ** **VÀ** **TỪ** **VIẾT**
> **TẮT**

||
||
||
||
||
||
||
||
||
||
||
||
||
||
||

||
||
||
||
||
||
||
||
||

> **DANH** **MỤC** **CÁC** **BẢNG** **BIỂU** **VÀ** **HÌNH** **ẢNH**

||
||
||
||
||
||
||
||
||
||
||
||

> **PHẦN** **1:** **THỰC** **TẬPTẠI** **CÔNG** **TY** **X**

**1.1.** **Giới** **thiệu** **về** **Công** **ty**

**1.1.1.** **Một** **số** **thông** **tin** **về** **công** **ty**

||
||
||
||

**1.1.2.** **Các** **sản** **phẩm** **của** **công** **ty**

> Đơn vị tập trung nghiên cứu, cung cấp các giải pháp điện toán đám mây
> tự chủ, bao

gồm: Máy chủ ảo hóa hiệu năng cao (Cloud Compute Virtual Machines), Hạ
tầng điều phối

Container số hóa (Managed Kubernetes Service) và Nền tảng lưu trữ hướng
đối tượng quy

mô lớn (Object Storage Platform).

**1.2.** **Nội** **dung** **thực** **tập** **tại** **công** **ty**

**1.2.1.** **Khái** **quát** **về** **Cloud** **Provider** **và**
**bài** **toán** **giám** **sát** **hạ** **tầng** **số**

Trong kỷ nguyên chuyển đổi số toàn diện, các Cloud Provider (AWS, Azure,
GCP, và các nhà cung cấp nội địa như Viettel IDC, VNG Cloud) đang dịch
chuyển mạnh mẽ sang kiến trúc Cloud-native. Hệ thống vận hành là các
mạng lưới phân tán quy mô lớn với hàng nghìn microservices liên kết chặt
chẽ.

> Dịch vụ giám sát hệ thống (tương tự như CloudWatch của AWS) đóng vai
> trò là "mắt và

tai" của toàn bộ hạ tầng, chịu trách nhiệm thu thập, phân tích và lưu
trữ ba trụ cột dữ liệu lớn (Observability Pillars):

> **-** **Metrics**: Chỉ số tài nguyên số hóa như CPU, RAM, Network I/O,
> IOPS và HTTP
>
> Request Rate.
>
> **-** **Logs**: Chuỗi văn bản nhật ký phi cấu trúc phát sinh từ nhân
> hệ điều hành, container và ứng dụng.
>
> **-** **Traces**: Luồng phân tích vòng đời yêu cầu xuyên suốt các
> microservices.
>
> Tuy nhiên, khối lượng dữ liệu khổng lồ phát sinh theo từng phần nghìn
> giây đã hoàn

toàn vượt quá giới hạn xử lý thủ công của con người. Điều này đặt ra bài
toán cấp thiết về

một hệ thống ứng dụng trí tuệ nhân tạo (AIOps) có khả năng tự động phân
tích hành vi

chuỗi thời gian, phát hiện lỗi dị biệt và phát cảnh báo sớm nhằm bảo vệ
tính liên tục của

hạ tầng số.

**1.2.2.** **Thực** **trạng** **thị** **trường** **AIOps** **năm**
**2026**

> Thị trườngAIOps toàn cầu năm 2026 ghi nhận quy mô doanh thu đạt từ
> 14.69 đến 18.95

tỷ USD, dự kiến duy trì tốc độ tăng trưởng kép (CAGR) khoảng 20-30% để
chạm mốc hơn

40 tỷ USD vào giai đoạn 2033–2034. Xu hướng dịch chuyển từ các công cụ
giám sát rời rạc sang nền tảng "Quan sát tích hợp" (Unified
Observability) đang diễn ra mạnh mẽ trên thế giới, định hình bởi các
giải pháp SaaS lớn như Datadog, Dynatrace, New Relic, Splunk hoặc các
dịch vụ nội tại DevOps Guru của AWS.

> Mặc dù có sự đầu tư mạnh mẽ, các Cloud Provider hiện nay vẫn phải đối
> mặt với ba

thách thức kỹ thuật cốt lõi:

> 1\. **Alert** **Fatigue** **(Hiện** **tượng** **ngập** **lụt**
> **cảnh** **báo)**: Trên 60% kỹ sư SRE và DevOps
>
> gặp tình trạng quá tải nhận thức do hệ thống gửi hàng nghìn thông báo
> lỗi mỗi ngày.
>
> Thống kê thực tế cho thấy 72-99% cảnh báo dựa trên ngưỡng cố định
> (Static
>
> Threshold) là báo động giả (False Positives), gây nhiễu và che khuất
> các sự cố
>
> nghiêm trọng thực sự.
>
> 2\. **Explainable** **AI** **(Trí** **tuệ** **nhân** **tạo** **có**
> **thể** **giải** **thích** **-** **XAI)**: Đội ngũ vận hành thường từ
> chối tin tưởng các cảnh báo lỗi từ mô hình học sâu nếu thuật toán hoạt
> động như một "hộp đen" bí ẩn. Xu hướng thị trường năm 2026 bắt buộc
> phải tích hợp lớp XAI để minh chứng lý do mô hình ra quyết định cảnh
> báo lỗi.
>
> 3\. **Sự** **trỗi** **dậy** **của** **LLM** **Agent** **và**
> **Copilot**: Sự tích hợp các mô hình ngôn ngữ lớn (OpenAI, Claude,
> Llama) vào hệ thống vận hành cho phép kỹ sư truy vấn hạ tầng bằng ngôn
> ngữ tự nhiên. AI đóng vai trò như một trợ lý tự động phân tích log hệ
> thống, vẽ biểu đồ tương quan và đề xuất trực tiếp câu lệnh khắc phục
> sự cố.
>
> Tại thị trường Việt Nam, các nhà cung cấp Local Cloud đang ưu tiên tìm
> kiếm giải pháp AIOps tự chủ công nghệ, tiết kiệm chi phí bản quyền dựa
> trên hệ sinh thái mã nguồn mở (Prometheus, Apache Kafka, ELK Stack).
> Do đặc thù sự cố hệ thống
>
> thật diễn ra không thường xuyên và thiếu hụt dữ liệu gán nhãn, việc
> ứng dụng các
>
> thuật toán Học máy không giám sát (Unsupervised Learning) để tự dò tìm
> điểm dị
>
> biệt là hướng đi tối ưu duy nhất.
>
> Sự bế tắc của các giải pháp giám sát truyền thống được thể hiện rõ qua
> các hạn chế sau:
>
> **-** Ngưỡng tĩnh cố định: Không thể tự điều chỉnh theo tính chu kỳ
> ngày/đêm hoặc biến động tải theo mùa của dịch vụ.
>
> **-** Thiếu khả năng tương quan dữ liệu: Không thể liên kết chuỗi sự
> kiện lỗi chéo giữa tầng mạng, tầng lưu trữ và tầng ứng dụng.
>
> **-** Quá tải dữ liệu: Tốc độ sinh metric vượt quá khả năng xử lý đồ
> thị trực quan bằng mắt thường của con người.
>
> **-** Phản ứng thụ động: Hệ thống chỉ cảnh báo khi sự cố sập nguồn đã
> xảy ra, hoàn toàn thiếu đi khả năng dự đoán chủ động (Proactive
> Prediction).

**1.2.3.** **Nghiên** **cứu** **các** **thuật** **toán** **phát**
**hiện** **bất** **thường** **tiên** **tiến**

> Để xây dựng bộ não AI Engine hoạt động hiệu quả trong môi trường không
> có dữ liệu gán nhãn, quá trình thực tập tập trung nghiên cứu cấu trúc
> lý thuyết của 4 thuật toán lõi:

**1.2.3.1.** **Isolation** **Forest**

> **-** **Bản** **chất** **toán** **học**: Thuật toán không xây dựng mô
> hình định nghĩa "sự bình thường" rồi tìm điểm lệch pha. Thay vào đó,
> nó cô lập trực tiếp các điểm dị biệt dựa trên cấu trúc hình học không
> gian dữ liệu. Gọi 𝑋 = {𝑥1,𝑥2,...,𝑥𝑛} là tập dữ liệu metric đầu vào gồm
> n mẫu trong không gian d chiều.
>
> **-** **Kiến** **trúc** **và** **Cơ** **chế** **thực** **thi**:
>
> **+** Thuật toán xây dựng một rừng gồm nhiều cây cô lập (iTree). Với
> mỗi iTree, một thuộc tính metric (ví dụ: cpu_utilization) được chọn
> ngẫu nhiên, sau đó một giá trị cắt p được chọn ngẫu nhiên trong khoảng
> \[min, max\] của thuộc tính đó.
>
> **+** Quá trình phân nhánh lặp lại liên tục cho đến khi: (cá biệt)
> điểm dữ liệu bị cô lập hoàn toàn, hoặc cây đạt chiều cao giới hạn.
>
> **+** Điểm số bất thường (Anomaly Score - s(x, n) của một mẫu dữ liệu
> x được tính
>
> bằng công thức:
>
> 𝐸(ℎ(𝑥)) 𝑠(𝑥,𝑛) = 2 𝑐(𝑛)
>
> Trong đó: h(x) là độ sâu của điểm x trên cây (số cạnh từ gốc đến lá),
> E(h(x)) là
>
> giá trị kỳ vọng độ sâu của x qua toàn bộ rừng iTree, và c(n) là độ sâu
> trung bình
>
> của một cây tìm kiếm nhị phân lỗi được xây dựng từ n phần tử.
>
> **-** **Luồng** **dữ** **liệu**:
>
> **+**
>
> **+**

**1.2.3.2.**

> *Input*: Ma trận metric đa biến tĩnh có kích thước (N x d).
>
> *Output*: Một vector S chứa các giá trị nằm trong khoảng \[0, 1\]. Nếu
> s(x, n) tiến
>
> gần tới 1, điểm dữ liệu được xác nhận là lỗi đột biến (Spike).

**Autoencoder**

> **-** **Bản** **chất** **toán** **học**: Là mạng nơ-ron học không giám
> sát nhằm tối ưu hóa hàm
>
> mất mát tái cấu trúc chênh lệch giữa đầu vào và đầu ra.
>
> **-** **Kiến** **trúc** **mạng**: Gồm hai khối mạng nơ-ron truyền
> thẳng (Fully Connected) hoặc
>
> tích chập mắc nối tiếp chéo nhau:
>
> **+** *Khối* *mã* *hóa* *(Encoder)*: Ánh xạ dữ liệu metric đầu vào 𝑋 ∈
> ℝ𝑑sang một
>
> không gian biểu diễn ẩn phục vụ nén tài 𝑍 ∈ ℝ𝑚 (với điều kiện ràng
> buộc số
>
> chiều m \<\< d qua hàm kích hoạt phi tuyến f:
>
> 𝑍 = 𝑓(𝑊 ⋅ 𝑋 + 𝑏𝑒)
>
> **+** Khối *giải* *mã* *(Decoder)*: Nhận ma trận nén Z và thực hiện
> ánh xạ ngược lại
>
> không gian gốc để tạo bản tái cấu trúc 𝑋 ∈ ℝ𝑑 qua hàm kích hoạt g:
>
> 𝑋 = 𝑔(𝑊 ⋅ 𝑍 + 𝑏𝑑) **-** **Luồng** **xử** **lý** **và** **Ngưỡng**
> **động** **POT-EVT**:
>
> **+** Hàm mất mát phục vụ tối ưu hóa trọng mạng (Loss Function) sử
> dụng Mean
>
> Squared Error (MSE): Loss = 𝑛 ∑‖𝑋 − 𝑋‖2
>
> **+** Trong pha inference thời gian thực, sai số này chính là Anomaly
> Score. Để tìm ngưỡng động, thuật toán **POT**
> **(Peak-Over-Threshold)** dựa trên **Lý** **thuyết** **giá** **trị**
> **cực** **hạn** **(EVT)** được áp dụng. POT không giả định dữ liệu
> tuân theo phân
>
> phối chuẩn Mean+Std. Nó lọc ra các giá trị Loss cực hạn vượt qua một
> ngưỡng
>
> ban đầu thấp t, sau đó khớp phân phối các giá trị vượt ngưỡng này vào
> hàm
>
> **Phân** **phối** **Pareto** **tổng** **quát** **(GPD)**:
>
> 𝐺(𝑟,𝜎)(𝑥) = 1 − (1 + 𝑟 ⋅ 𝑥)−𝑟
>
> Từ hàm phân phối xác suất GPD, hệ thống tính toán ra một ngưỡng động
> thông
>
> minh 𝜏 thay đổi liên tục theo thời gian thực dựa trên một xác suất rủi
> ro định
>
> trước (ví dụ q = 0.001), đảm bảo loại bỏ nhiễu biên tối đa.

**1.2.3.3.** **Mạng** **Long** **Short-Term** **Memory** **(LSTM)**

> **-** **Bản** **chất** **toán** **học**: Mạng LSTM (Bộ nhớ ngắn hạn
> dài) là một kiến trúc cải tiến
>
> của Mạng nơ-ron hồi quy (RNN) truyền thống. RNN cơ bản gặp hiện tượng
> tiêu
>
> biến gradient (Vanishing Gradient) khi lan truyền ngược qua các chuỗi
> thời gian dài,
>
> khiến mô hình quên mất các đặc trưng trong quá khứ xa.LSTM giải quyết
> triệt để bài toán này bằng cách đưa vào khái niệm **Trạng** **thái**
> **ô** **(Cell** **State)** — đóng vai trò như một băng chuyền thông
> tin tuyến tính chạy xuyên suốt qua các bước thời gian, cho phép dòng
> thông tin lịch sử được lưu truyền nguyên vẹn và liên tục.
>
> **-** **Kiến** **trúc** **mạng** **và** **Cơ** **chế** **kiểm**
> **soát** **luồng** **thông** **tin** **(Gates)**: Tại mỗi bước thời
> gian t, một ô logic LSTM nhận 3 tín hiệu đầu vào: Dữ liệu hiện tại 𝑥𝑡,
> trạng thái ẩn của bước trước ℎ𝑡−1, và trạng thái ô của bước trước 𝐶−1.
> Luồng thông tin trong ô được điều khiển nghiêm ngặt bởi 3 cổng logic
> sử dụng hàm kích hoạt Sigmoid (trả về giá trị trong khoảng \[0, 1\] để
> quyết định tỷ lệ thông tin được đi qua):
>
> 1\. **Cổng** **quên** **(Forget** **Gate** **-** **f\_{t})**: Quyết
> định lượng thông tin lịch sử nào từ trạng thái ô cũ C\_{t-1} sẽ bị xóa
> bỏ.
>
> 𝑓 = 𝜎(𝑊 ⋅ \[ℎ𝑡−1,𝑥𝑡\] + 𝑏)
>
> 2\. **Cổng** **vào** **(Input** **Gate** **-** 𝑖𝑡**)** **và** **Tầng**
> **cập** **nhật** **trạng** **thái** (~𝐶**)**: Quyết định lượng thông
> tin mới nào từ dòng dữ liệu hiện tại sẽ được ghi nhận vào trạng thái
> ô.
>
> 𝑖𝑡 = 𝜎(𝑊 ⋅ \[ℎ𝑡−1,𝑥𝑡\] + 𝑏)
>
> ~𝐶 = tanh(𝑊 ⋅ \[ℎ𝑡−1,𝑥𝑡\] + 𝑏𝑐)
>
> 3\. **Cập** **nhật** **trạng** **thái** **ô** **(**𝐶**)**: Kết hợp kết
> quả từ cổng quên và cổng vào để thiết lập bộ nhớ mới cho ô.
>
> 𝐶 = 𝑓 ∗ 𝐶−1 + 𝑖𝑡 ∗ ~𝐶
>
> 4\. **Cổng** **ra** **(Output** **Gate** **-** 𝑜𝑡**)** **và**
> **Trạng** **thái** **ẩn** **(**ℎ𝑖**)**: Quyết định giá trị đầu ra kế
> tiếp và chuyển giao trạng thái ẩn h\_{t} sang bước thời gian sau.
>
> 𝑜𝑡 = 𝜎(𝑊 ⋅ \[ℎ𝑡−1,𝑥𝑡\] + 𝑏𝑜) ℎ𝑡 = 𝑜𝑡 ∗ tanh(𝐶)
>
> **-** **Luồng** **dữ** **liệu**:
>
> • *Input*: Một tensor chuỗi thời gian ba chiều có kích thước
> (Batch_size, Window_size, Features_num).
>
> • *Output*: Một vector dự báo có kích thước (Batch_size, Features_num)
> đại diện cho xu hướng tài nguyên ở bước kế tiếp.

**1.2.3.4.** **Mạng** **Temporal** **Convolutional** **Network**
**(TCN)** **kết** **hợp** **Attention**

> **-** **Bản** **chất** **toán** **học**: TCN thay thế các cấu hình
> mạng hồi quy RNN/LSTM truyền thống bằng cấu trúc mạng tích chập 1
> chiều (1D-CNN) có ràng buộc nhân quả, xử lý dữ liệu chuỗi thời gian
> song song hóa.
>
> **-** **Kiến** **trúc** **mạng**:
>
> 1\. Tích chập nhân quả (Causal Convolutions): Đảm bảo bộ lọc tại thời
> điểm t chỉ liên kết với các phần tử tại thời điểm t, t-1, t-2... ở
> tầng trước đó, loại bỏ hoàn toàn việc lộ dữ liệu tương lai.
>
> 2\. Tích chập giãn nở (Dilated Convolutions): Phép toán tích chập trên
> phần tử F với hệ số giãn nở d lên chuỗi đầu vào x được định nghĩa toán
> học:
>
> 𝑘−1
>
> 𝐹(𝑠) = ∑𝑓 (𝑖) ⋅ 𝑥𝑠−𝑑⋅𝑖 𝑖=0
>
> Bằng cách tăng giá trị d theo cấp số nhân (𝑑 = 2𝑙với l là độ sâu tầng
> mạng), TCN
>
> mở rộng vùng quan sát lịch sử (Receptive Field) cực lớn mà không làm
> tăng số
>
> lượng tham số tính toán.
>
> 3\. Cơ chế Bahdanau Attention: Chuỗi vector đặc trưng trích xuất từ
> TCN được đưa
>
> qua tầng Attention để tính toán ma trận trọng số chú ý động 𝛼𝑡. Trọng
> số này đo lường mức độ ảnh hưởng của trạng thái quá khứ đối với hành
> vi metric hiện tại, giúp mạng nơ-ron bỏ qua các biến động nhiễu ngẫu
> nhiên và khóa chặt vào chu kỳ chính.
>
> **-** **Luồng** **dữ** **liệu**:
>
> **+** *Input*: Một cửa sổ trượt (Sliding Window) dữ liệu metric có
> kích thước (Batch_size x Window_size x Metrics_num).
>
> **+** *Output*: Giá trị metric dự báo cho thời điểm kế tiếp t+1. Sai
> lệch giữa giá trị dự báo từ TCN và giá trị thực tế sẽ được đưa qua bộ
> lọc EVT để xác nhận bất thường.

**1.2.4.** **Nghiên** **cứu** **kỹ** **thuật** **giảm** **nhiễu** **và**
**gom** **cụm** **sự** **cố**

> Để giải quyết nạn Alert Fatigue, bên cạnh phát hiện lỗi, cần phải "lọc
> rác" một cách thông minh:

**1.2.4.1.** **Drain3**

> **-** **Bản** **chất** **và** **Kiến** **trúc**: Drain3 sử dụng kiến
> trúc cây định danh có độ sâu cố định (Fixed-depth Tree) để xử lý và
> phân loại các dòng log phi cấu trúc theo thời gian thực thành các mẫu
> template dạng biểu thức chính quy.
>
> **-** **Luồng** **thực** **thi** **qua** **4** **tầng** **cây**:
>
> \[ Log Thô \] ──\> (Tầng 1: Chiều dài log ) ──\> (Tầng 2: Token đầu
> tiên)
>
> ──\> (Tầng 3: Điểm số tương đồng ) ──\> \[Log Template ID\]
>
> **+** Tầng *1* *(Root* *Node)*: Phân nhánh dựa trên tổng số lượng
> Token (độ dài ký tự
>
> khoảng trắng) của chuỗi log.
>
> **+** *Tầng* *2* *(Internal* *Nodes)*: Phân nhánh dựa trên ký tự văn
> bản của các Token đầu tiên (thường là tên class hoặc mã lỗi hệ thống).
>
> **+** *Tầng* *3* *(Leaf* *Nodes)*: Tính toán điểm số tương đồng
> (SimScore) giữa dòng log mới nhập và các Template có sẵn tại node lá
> dựa trên số lượng token khớp nhau.
>
> **+** *Cập* *nhật* *động*: Nếu SimScore \> Ngưỡng, dòng log được xếp
> vào Template đó
>
> và biến các ký tự số/IP động thành dấu wildcard \*. Ngược lại, Drain3
> tự động
>
> sinh ra một cụm Template mới trực tuyến.
>
> **-** **Luồng** **dữ** **liệu**:
>
> **+**
>
> **+**

**1.2.4.2.**

> *Input*: Luồng log text thô từ Kafka topic cloud-logs.
>
> *Output*: Log Template ID kèm ma trận văn bản đã làm sạch biến số,
> giảm tải
>
> token xử lý cho mô hình ngôn ngữ lớn.

**Thuật** **toán** **ST-DBSCAN** **(Gom** **cụm** **không** **-**
**thời** **gian)**

> **-** **Bản** **chất** **toán** **học**: Là thuật toán mở rộng từ
> DBSCAN truyền thống, định nghĩa
>
> mật độ cụm dựa trên hai hàm khoảng cách độc lập: Khoảng cách không
> gian
>
> (Spatial) và Khoảng cách thời gian (Temporal).
>
> **-** **Cơ** **chế** **thực** **thi**: Một điểm cảnh báo sự cố p được
> coi là điểm lõi (Core Point) nếu trong vùng lân cận của nó chứa tối
> thiểu một số lượng điểm cảnh báo 𝑀𝑖𝑛𝑃𝑡𝑠.
>
> 1\. *Hàm* *khoảng* *cách* *thời* *gian*: 𝐷ime(𝑝,𝑞) = \|𝑡𝑝 − 𝑡𝑞\| ≤
> 𝐸𝑝𝑠2(cấu hình mặc định là 60 giây).
>
> 2\. *Hàm* *khoảng* *cách* *không* *gian*: Định nghĩa dựa trên khoảng
> cách đồ thị mạng (Topology Distance). Ví dụ: 𝐷space(𝑝,𝑞) = 0 nếu cùng
> một Pod; =1 nếu cùng Node; =2 nếu cùng Namespace hạ tầng.
>
> **-** **Luồng** **dữ** **liệu**:
>
> o *Input*: Tập hợp các vector cảnh báo thô phát sinh liên tục trong hệ
> thống 𝐴 =
>
> {(𝑡𝑖,𝑝𝑜𝑑𝑖,𝑛𝑜𝑑𝑒𝑖,𝑚𝑒𝑡𝑟𝑖𝑐_𝑒𝑟𝑟𝑜𝑟)}.
>
> o *Output*: Các tập hợp cụm Incident. Toàn bộ các cảnh báo có liên đới
> nhân
>
> quả sẽ bị "giam" vào cùng một mã Incident ID duy nhất để chuyển tiếp
> sang
>
> pha xử lý tự động RCA bằng Generative AI.

**1.2.5.** **Nghiên** **cứu** **ứng** **dụng** **Generative** **AI**
**(LLM** **&** **RAG)**

> Năm 2026 đánh dấu sự bùng nổ của việc tích hợp AI tạo sinh vào hạ
> tầng. Vì vậy
>
> trong kỳ thực tập, em đã nghiên cứu mô hình **RAG**
> **(Retrieval-Augmented**
>
> **Generation)**:

**1.2.5.1.** **Kiến** **trúc** **RAG** **(Retrieval-Augmented**
**Generation)**

> Nếu chỉ quăng trực tiếp Log thô vào mô hình ngôn ngữ lớn (LLM), mô
> hình sẽ gặp
>
> hiện tượng "ảo giác" (Hallucination) - tự bịa ra nguyên nhân lỗi do
> thiếu ngữ cảnh
>
> hạ tầng. Kiến trúc RAG khắc phục điều này bằng cách xây dựng một
> Vector Database nội bộ (dùng ChromaDB hoặc Faiss), lưu trữ toàn bộ:
> Tài liệu kiến trúc hệ thống, lịch sử các sự cố đã sửa trong quá khứ và
> các tài liệu hướng dẫn vận hành chuẩn (Runbooks) của công ty.

**1.2.5.2.** **Luồng** **suy** **luận** **CoT** **(Chain-of-Thought)**
**cấu** **trúc** **hóa**

> Khi hệ thống ST-DBSCAN xác nhận một Incident, một Python Script sử
> dụng framework LangChain sẽ lập tức thực thi luồng xử lý tự động:
>
> 1\. Truy vấn ngữ cảnh: Trích xuất các dòng log lỗi đã làm sạch qua
> Drain3 + biểu đồ xu hướng biến động metric từ TCN.
>
> 2\. Truy xuất tri thức: Dùng cơ chếVector Search đểtìm kiếm các đoạn
> Runbook hướng dẫn xử lý lỗi tương đồng trong Vector Database.
>
> 3\. Kích hoạt CoT: Tổng hợp toàn bộ dữ liệu trên vào một Prompt chuyên
> dụng, ép LLM suy luận từng bước theo kỹ thuật Chuỗi tư duy
> (Chain-of-Thought): Phân tích triệu chứng -\> Liên kết nguyên nhân quả
> -\> Đưa ra kết luận Root Cause và câu lệnh Shell khắc phục cụ thể. Đầu
> ra được định dạng chuẩn JSON (Output Parsing) để sẵn sàng đẩy sang hệ
> thống Webhook của Slack,Telegram,…
>
> **PHẦN** **2:** **THỰC** **TẬP** **CHUYÊN** **SÂU** **TẠI** **CÔNG**
> **TY**

**2.1.** **Tổng** **quan** **về** **hạ** **tầng** **thực** **nghiệm**

> Để phục vụ mục tiêu nghiên cứu, đánh giá độc lập hiệu năng và độ chính
> xác của
>
> các mô hình trí tuệ nhân tạo (AI Engine Core), em đã xây dựng một môi
> trường Lab
>
> thực nghiệm giả lập để kiểm thử thuật toán dựa trên kiến trúc Python
> sinh dữ liệu.
>
> Các thành phần phân lớp chức năng của hạ tầng thực nghiệm bao gồm:
>
> **-** Môi trường tínhtoánthuật toán:Sửdụng ngôn ngữlập trình
> Python3.12, framework Học sâu PyTorch để định nghĩa cấu trúc mạng
> nơ-ron, kết hợp thư viện scikit-learn cho các thuật toán nền tảng.
>
> **-** Hạ tầng cơ sở dữ liệu giả lập (Data Mock Pipeline):
>
> **+** Lớp Metrics (Dữ liệu chuỗi thời gian): Xây dựng các hàm toán học
> có tính chu kỳ(Sine/Cosine) kết hợp nhiễu ngẫu nhiên (Gaussian Noise)
> để mô phỏng hành vi tải CPU, RAM và Network của hệ thống Cloud thật
> qua từng phút.
>
> **+** Lớp Logs (Dữ liệu văn bản phi cấu trúc): Thiết lập một tập từ
> điển chứa các chuỗi thông điệp nhật ký hệ thống tiêu chuẩn (như
> "Health check OK") và các chuỗi văn bản cảnh báo lỗi phân tán (như
> "OOMKilled", "Connection timeout").
>
> **-** Hạ tầng Kỹ nghệ tạo sự cố (Chaos Engineering Simulation): Để tạo
> tập dữ liệu kiểm thử (Test set) có nhãn đối chiếu, hệ thống Lab cài
> đặt các module chủ động "bơm" lỗi dị biệt (Synthetic Anomalies) vào
> dòng dữ liệu tại các mốc thời gian cố định (Timestamp), bao gồm: giả
> lập lỗi đột biến tài nguyên (Spike), lỗi rò rỉ bộ nhớ tăng dần (Memory
> Leak) và lỗi ngắt kết nối dịch vụ chéo Xây dựng pipeline thu thập dữ
> liệu.

**2.2.** **Xây** **dựng** **pipeline** **thu** **thập** **và** **mô**
**phỏng** **dữ** **liệu**

> Do giới hạn thực nghiệm tập trung chuyên sâu vào pha xử lý của thuật
> toán, luồng dữ liệu (Data Pipeline) đầu vào không thu thập trực tiếp
> từ các Agent vật lý mà được thiết kế dưới dạng Luồng dữ liệu Stream
> đóng gói cấu trúc định dạng JSON mẫu, mô phỏng chính xác kiến trúc
> hướng sự kiện (Event-Driven) của các Cloud Provider lớn

<img src="./g2dehto2.png"
style="width:6.47569in;height:0.92633in" />

> *Hình* *2.1:* *Pipeline* *xử* *lý* *của* *AI* *Engine*
>
> **-** Cấu trúc hóa luồng Metric đầu vào: Dữ liệu Metrics được tạo bằng
> thư viện NumPy
>
> dưới dạng mảng 2D với kích thước (N, 3), trong đó N là số mẫu và 3 cột
> tương ứng
>
> với các chỉ số cpu, ram, network. Dữ liệu sau đó được chuẩn hóa về
> khoảng \[0,1\]
>
> và chia thành các cửa sổ trượt (sliding window) để tạo thành mảng 3D
> (số cửa sổ,
>
> window_size, số_features) phù hợp với đầu vào của mô hình TCN.
>
> cpu ram network
>
> 0 0.549671 0.486174 0.564769 1 0.652303 0.476585 0.476586 2 0.657921
> 0.576743 0.453053 3 0.554256 0.453658 0.453427 4 0.524196 0.308672
> 0.327508 5 0.443771 0.398717 0.531425 6 0.409198 0.358770 0.646565 7
> 0.477422 0.506753 0.357525 8 0.445562 0.511092 0.384901 9 0.537570
> 0.439936 0.470831
>
> **-** Dữ liệu Logs được tạo dưới dạng danh sách các chuỗi văn bản, sau
> đó được xử lý tuần tự qua Drain3 để trích xuất template và TF-IDF để
> lọc log bất thường.
>
> \['INFO Health check OK', 'INFO Health check OK', 'INFO Health check
> OK', 'INFO Health check OK', 'INFO Health check OK', 'INFO Health
> check OK', 'INFO Health check OK', 'INFO Health check OK', 'INFO
> Health check OK', 'INFO Health check OK', 'INFO Health check OK',
> 'INFO Health check OK', 'INFO Health check OK', 'INFO Health check
> OK', 'INFO Health check OK', 'ERROR OOMKilled pod api-service', 'ERROR
> Connection timeout to 192.168.1.1'\]

**2.3.** **Cài** **đặt** **thuật** **toán** **và** **xây** **dựng**
**AI** **Engine**

**2.3.1.** **Tiền** **xử** **lý** **dữ** **liệu**

> Dữ liệu đầu vào cho hệ thống AI Engine bao gồm hai loại chính:
> **Metrics** **(dữ** **liệu**
>
> **chuỗi** **thời** **gian)** và **Logs** **(dữ** **liệu** **văn**
> **bản)**.
>
> **a.** **Tiền** **xử** **lý** **Metrics:**
>
> Dữ liệu metrics được thu thập từ Prometheus dưới dạng chuỗi thời gian
> với các chỉ số CPU, RAM, Network. Quá trình tiền xử lý bao gồm:
>
> 1\. Chuẩn hóa dữ liệu (Normalization): Sử dụng MinMaxScaler để chuẩn
> hóa dữ liệu về khoảng \[0, 1\], giúp mô hình học hiệu quả hơn và tránh
> ảnh hưởng của các chỉ số có giá trị lớn.
>
> 2\. Tạo cửa sổ thời gian (Sliding Window): Dữ liệu được chia thành các
> cửa sổ trượt với kích thước seq_len = 60 (tương ứng 60 mẫu dữ liệu).
> Mỗi cửa sổ sẽ được sử dụng làm đầu vào cho mô hình TCN.
>
> def preprocess_data(self, df: pd.DataFrame) -\> np.ndarray: scaled =
> self.scaler.fit_transform(df.values)
>
> X = \[\]
>
> for i in range(len(scaled) - self.seq_len):
> X.append(scaled\[i:i+self.seq_len\])
>
> return np.array(X) **b.** **Tiền** **xử** **lý** **Logs:**
>
> Logs được xử lý qua hai bước:
>
> 1\. Drain3: Trích xuất template (mẫu) từ các dòng log, loại bỏ các
> biến số thay đổi
>
> như IP, timestamp.
>
> Ví dụ: "Connection timeout to 192.168.1.1" → "Connection timeout to
> \<\*\>"
>
> 2\. TF-IDF: Đánh trọng số cho các template log, giữ lại các template
> có tần suất xuất
>
> hiện thấp (bất thường) và loại bỏ các template phổ biến (như "Health
> check OK").
>
> def filter_anomalous_logs(self, log_lines: List\[str\], top_k: int =
> 10) -\> List\[Dict\]: templates = self.parse_logs(log_lines)
>
> if len(set(templates)) \< 2: return \[\]
>
> tfidf = self.vectorizer.fit_transform(templates)

<img src="./aaoqq3pb.png" style="width:2.92361in;height:0.75in" /><img src="./xqxzsr5h.png"
style="width:6.04861in;height:0.88889in" />

> scores = np.array(tfidf.mean(axis=1)).flatten() top_indices =
> np.argsort(scores)\[-top_k:\]\[::-1\] return \[{
>
> "original": log_lines\[i\], "template": templates\[i\], "score":
> scores\[i\]
>
> } for i in top_indices if scores\[i\] \> 0\]
>
> Quá trình tiền xử lý dữ liệu Metrics và Logs
>
> *Hình* *2.2:* *Quá* *trình* *tiền* *xử* *lý* *dữ* *liệu* *Metrics.*
>
> *Hình* *2.3:* *Quá* *trình* *tiền* *xử* *lý* *dữ* *liệu* *Logs*

**2.3.2.** **Xây** **dựng** **mô** **hình** **phát** **hiện** **bất**
**thường** **(TCN** **+Attention** **+** **EVT)**

> Mô hình phát hiện bất thường được xây dựng dựa trên kiến trúc TCN
> (Temporal

Convolutional Network) kết hợp Cơ chế Attention và Lý thuyết giá trị cực
trị EVT

(Extreme Value Theory)**.**

**a.** **Kiến** **trúc** **TCN** **+Attention:**

> TCN sử dụng các lớp tích chập nhân quả (causal convolution) với độ
> giãn (dilation) tăng

dần, cho phép mô hình học các phụ thuộc dài hạn trong chuỗi thời gian
một cách hiệu quả

và song song hóa tốt hơn LSTM. Cơ chế Attention giúp mô hình tập trung
vào các mốc thời gian quan trọng (ví dụ: giờ cao điểm hệ thống).

class TCNWithAttention(nn.Module):

def \_\_init\_\_(self, input_dim: int, hidden_dim: int = 64, num_layers:
int = 4, kernel_size: int = 3, dropout: float = 0.1):

> super().\_\_init\_\_() self.hidden_dim = hidden_dim layers = \[\]
>
> for i in range(num_layers): dilation = 2 \*\* i
>
> padding = (kernel_size - 1) \* dilation // 2 \# \<--- ĐÃ SỬA
> layers.append(nn.Conv1d(
>
> in_channels=input_dim if i == 0 else hidden_dim,
> out_channels=hidden_dim, kernel_size=kernel_size,
>
> padding=padding, dilation=dilation
>
> )) layers.append(nn.ReLU())
>
> layers.append(nn.Dropout(dropout)) self.tcn = nn.Sequential(\*layers)

self.attention = nn.MultiheadAttention(embed_dim=hidden_dim,
num_heads=4, dropout=dropout, batch_first=True)

> self.decoder = nn.Linear(hidden_dim, input_dim)

**b.** **EVT** **-** **Extreme** **Value** **Theory** **(Ngưỡng**
**động):**

> Thay vì sử dụng ngưỡng tĩnh Mean + 3\*Std, EVT xác định ngưỡng động
> dựa trên phân

phối đuôi (heavy-tail) của sai số tái tạo (Reconstruction Loss). Phương
pháp Peak Over

Threshold (POT) được áp dụng để ước lượng ngưỡng phù hợp với từng thời
điểm.

> def find_threshold_evt(self, X_val: np.ndarray, quantile: float =
> 0.99) -\> float: losses = self.compute_loss(X_val)
>
> init_thresh = np.percentile(losses, quantile \* 100) peaks =
> losses\[losses \> init_thresh\]
>
> if len(peaks) \< 10:
>
> self.threshold = np.mean(losses) + 3 \* np.std(losses) else:
>
> params = genpareto.fit(peaks - init_thresh)
>
> self.threshold = init_thresh + genpareto.ppf(0.99, \*params) return
> self.threshold

**c.** **Quá** **trình** **huấn** **luyện:**

> Mô hình được huấn luyện trên dữ liệu bình thường (không có lỗi) với 30
> epochs. Loss

function là Mean Squared Error (MSE) giữa dữ liệu gốc và dữ liệu tái
tạo.

<img src="./tklpj5gf.png" style="width:6.5in;height:3.84236in" /><img src="./hp3scol2.png"
style="width:4.59722in;height:2.72917in" />

> *Hình* *2.4:* *Biểu* *đồ* *Loss* *trong* *quá* *trình* *huấn* *luyện*
> *mô* *hình* *TCN* *+* *Attention.*
>
> *Hình* *2.5:* *Kết* *quả* *phát* *hiện* *bất* *thường* *trên* *dữ*
> *liệu* *test.*

**2.3.3.** **Xây** **dựng** **module** **lọc** **Log** **và** **giảm**
**nhiễu** **cảnh** **báo** **(Drain3** **&** **ST-DBSCAN)**

Drain3 là thuật toán online log parsing, giúp trích xuất template từ log
và loại bỏ các biến số. Sau khi parse, TF-IDF được sử dụng để đánh trọng
số và giữ lại các template có tần suất thấp (bất thường).

<img src="./recehcll.png"
style="width:4.05556in;height:1.49306in" /><img src="./vlvywqj4.png"
style="width:3.03722in;height:0.37708in" />

Kết quả trên tập log mẫu:

> *Hình* *2.6:* *Kết* *quả* *lọc* *log* *bất* *thường* *với* *Drain3*
> *và* *TF-IDF.*
>
> ST-DBSCAN (Spatio-Temporal DBSCAN) gom các alert liên quan thành một
> Incident

duy nhất dựa trên:

> **-** **Không** **gian** **(Spatial):** Các alert đến từ cùng một Node
> (node_id).
>
> **-** **Thời** **gian** **(Temporal):** Các alert xảy ra trong khoảng
> thời gian ≤ 60 giây.
>
> CLUSTER_EPS_SPACE = float(os.getenv("CLUSTER_EPS_SPACE", "1.0"))
> CLUSTER_EPS_TIME = int(os.getenv("CLUSTER_EPS_TIME", "60")) \# seconds
> CLUSTER_MIN_SAMPLES = int(os.getenv("CLUSTER_MIN_SAMPLES", "2"))
>
> *Hình* *2.7:* *Kết* *quả* *gom* *cụm* *5* *alert* *thành* *1*
> *Incident.*

**2.3.4.** **Xây** **dựng** **module** **phân** **tích** **nguyên**
**nhân** **sử** **dụng** **LangChain** **và** **Ollama**

> Module RCA (Root Cause Analysis) sử dụng LangChain kết hợp với Ollama
> (mô hình

Qwen2.5 7B chạy local) để phân tích nguyên nhân gốc rễ của sự cố.

**a.** **Kiến** **trúc** **RAG** **(Retrieval-Augmented**
**Generation):**

RAG bao gồm hai thành phần chính:

> **-** Vector Database (ChromaDB): Lưu trữ các runbook (tài liệu hướng
> dẫn sửa lỗi) dưới
>
> dạng vector embedding. Khi có sự cố, hệ thống tìm kiếm các runbook
> liên quan nhất.
>
> **-** LLM (Ollama): Nhận context từ runbook và thông tin sự cố, phân
> tích và trả về báo
>
> cáo dạng JSON.

**b.** **Cấu** **hình** **Ollama:**

> OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL",
> "http://localhost:11434") OLLAMA_MODEL = os.getenv("OLLAMA_MODEL",
> "qwen2.5:7b") OLLAMA_EMBEDDING_MODEL =
> os.getenv("OLLAMA_EMBEDDING_MODEL",

"nomic-embed-text")

**c.** **Chain-of-Thought** **Prompt:**

\*\*Log lỗi:\*\* {logs} \*\*Metrics:\*\* {metrics} \*\*Thời gian:\*\*
{timestamp} \*\*Service:\*\* {service}

\*\*Runbook tham khảo:\*\* {context}

Hãy phân tích theo 3 bước: 1. Triệu chứng chính

2\. Nguyên nhân gốc

3\. Giải pháp khắc phục

Trả về JSON: {{

> "severity": "critical/warning/info", "root_cause": "nguyên nhân gốc",
> "suggested_action": "hành động", "affected_service": "{service}",
> "confidence": 0.0-1.0

}}

<img src="./m4eneisv.png" style="width:6.5in;height:2.09653in" />

**d.** **Kết** **quả** **RCA:**

> *Hình* *2.8:* *Báo* *cáo* *RCA* *từ* *LLM* *Ollama.*

**2.4.** **Thử** **nghiệm** **và** **đánh** **giá** **hiệu** **năng**
**(Demo)**

**2.4.1.** **Kịch** **bản** **thử** **nghiệm**

> **Kịch** **bản** **1:** **Phát** **hiện** **bất** **thường** **trên**
> **Metrics**
>
> **-** Tạo dữ liệu giả gồm 500 mẫu bình thường và 30 mẫu bất thường
>
> (CPU/RAM/Network tăng đột biến).
>
> **-** Mô hình TCN + Attention + EVT phát hiện thành công 29/30 điểm
> bất thường. **Kịch** **bản** **2:** **Lọc** **Log** **bất** **thường**
>
> **-** Tập log: 100 dòng "Health check OK" + 2 dòng lỗi ("OOMKilled",
> "Connection timeout").
>
> **-** Kết quả: 2 dòng lỗi được phát hiện và đánh dấu là bất thường.
> **Kịch** **bản** **3:** **Gom** **cụm** **cảnh** **báo**
>
> **-** 5 alert được tạo từ các điểm bất thường, ST-DBSCAN gom thành 1
> Incident duy nhất.
>
> **Kịch** **bản** **4:** **Phân** **tích** **nguyên** **nhân**
> **(RCA)**
>
> **-** RCAAgent nhận Incident và log lỗi, gọi Ollama để phân tích.

**-** LLM trả về báo cáo JSON với root_cause và suggested_action.
**2.4.2.** **Kết** **quả** **đánh** **giá**

<img src="./soo0nttn.png" style="width:6.5in;height:3.3375in" />

||
||
||
||
||
||
||
||

> *Hình* *2.9:* *Kết* *quả* *toàn* *bộ* *pipeline* *chạy* *thành*
> *công.*
>
> **2.4.3.** **Đánh** **giá**
>
> Hệ thống AI Engine đáp ứng được các yêu cầu:
>
> 1\. Phát hiện bất thường chính xác: Mô hình TCN + Attention + EVTđạt
> độ chính
>
> xác cao.
>
> 2\. Giảm nhiễu cảnh báo: Lọc log và gom cụm giúp giảm đáng kể số lượng
> cảnh báo cần xử lý.
>
> 3\. Phân tích RCA tự động: Ollama local cung cấp phân tích nguyên nhân
> chính xác, không phụ thuộc vào API bên ngoài.
>
> 4\. Tiết kiệm chi phí: Toàn bộ hệ thống chạy local, không phát sinh
> chi phí.
>
> **KẾT** **LUẬN**
>
> Trong thời gian thực tập, em đã hoàn thành các đầu việc: nghiên cứu cơ
> sở lý thuyết

về mạng tích chập chuỗi thời gian (TCN), cơ chế Attention, lý thuyết xác
suất cực hạn

EVT, thuật toán phân tách log trực tuyến Drain3, gom cụm không - thời
gian ST-DBSCAN và kiến trúc RAG kết hợp mô hình ngôn ngữ lớn (LLM); khảo
sát thực trạng quy trình giám sát hệ thống và vấn đề ngập lụt cảnh báo
tại đơn vị; đề xuất kiến trúc tổng thể và xây dựng, thử nghiệm thành
công prototype AI Engine Core với kết quả bước đầu khả quan.

> Hệ thống đã hiện thực được các thành phần cốt lõi: module tiền xử lý
> dữ liệu chuẩn

hóa MinMax và tạo cửa sổ trượt trên dữ liệu metrics đa biến (CPU, RAM,
Network); mô hình phát hiện bất thường TCN kết hợp Attention và bộ lọc
ngưỡng động EVT(Peak-Over-Threshold); bộ phân tách log trực tuyến Drain3
kết hợp TF-IDF để lọc log bất thường và module gom cụm không - thời gian
ST-DBSCAN giảm nhiễu cảnh báo; cùng lớp RCA Agent sử dụng LangChain kết
hợp Ollama Qwen2.5 7B chạy local và ChromaDB để truy xuất Runbook tri
thức và phân tích nguyên nhân gốc sự cố. Kịch bản thử nghiệm giả lập
end-to-end trên bộ dữ liệu 700 mẫu bình thường và 30 mẫu bất thường cho
thấy chuỗi thu thập – phát hiện bất thường – gom cụm giảm nhiễu – báo
cáo RCAtự động hoạt động đúng kỳ vọng.

> Quá trình thực tập giúp em củng cố kiến thức đã học về học máy và học
> sâu, tiếp cận

sâu các công nghệ AI hiện đại (TCN, Attention, EVT, RAG, LLM) và kỹ
thuật vận hành

hệ thống (AIOps), tích lũy kinh nghiệm thực tế, tạo tiền đề để hoàn
thiện đồ án tốt nghiệp

Thạc sĩ. Hướng phát triển tiếp theo gồm: tối ưu mô hình AI Core, nâng
cấp Vector Database với kho dữ liệu Runbook và lịch sử sự cố thực tế,
tích hợp với các công cụ mã nguồn mở (Prometheus, Grafana, Loki, Kafka)
để xây dựng nền tảng AIOps hoàn chỉnh, và bổ sung cơ chế tự động khắc
phục sự cố (Auto-Remediation) thông qua kết nối LLM Agent với Kubernetes
Operator.

Em xin chân thành cảm ơn thầy giáo hướng dẫn và đơn vị thực tập đã tạo
điều kiện và tận tình giúp đỡ trong suốt quá trình thực tập!

> **TÀI** **LIỆU** **THAM** **KHẢO**

\[1\] Bai, S., Kolter, J. Z., & Koltun, V. (2018). An empirical
evaluation of generic convolutional and recurrent networks for sequence
modeling. *arXiv* *preprint* *arXiv:1803.01271*.

\[2\] He, P., Zhu, J., Zheng, Z., & Lyu, M. R. (2017). Drain: An online
log parsing approach with fixed depth tree. In *Proceedings* *of* *the*
*24th* *International* *Conference* *on* *Web* *Services* *(ICWS)*, pp.
33–40. IEEE.

\[3\] Lewis, P., Perez, E., Piktus, A., et al. (2020).
Retrieval-augmented generation for knowledge-intensive NLP tasks. In
*Advances* *in* *Neural* *Information* *Processing* *Systems*
*(NeurIPS)*, Vol. 33, pp. 9459–9474.

\[4\] Yu, L. (2023). DTAAD: Dual TCN-attention networks for anomaly
detection in multivariate time series data. *arXiv* *preprint*
*arXiv:2302.10753*.

\[5\] Zhong, Z., et al. (2023). A survey of time series anomaly
detection methods in the AIOps domain. *arXiv* *preprint*
*arXiv:2308.00393*.

\[6\] Zhang, Y., et al. (2025). Wavelet-enhanced temporal convolutional
autoencoder with self-attention for unsupervised anomaly detection in
high-performance computing systems. In *2025* *IEEE* *International*
*Conference* *on* *High-Performance* *Computing* *(HPC)*. IEEE.

\[7\] Alif, F. K., et al. (2026). Hybrid clustering and extreme value
theory for anomaly detection in electricity consumption: A case study on
Tetouan's grid. *DTIC* *Dimensions*.

\[8\] Putri, M. H., & Sari, D. P. (2025). Earthquake point clustering in
Sumatra Island using spatio-temporal density-based spatial clustering
application with noise (ST-DBSCAN) algorithm. *Mathematical* *Journal*
*of* *Modelling* *and* *Forecasting*, 3(1).

\[9\] Drain3 Development Team. (2020). Drain3: Persistent log parser.
*PyPI*. Available at:
[<u>https://pypi.org/project/drain3/\[reference:10\]</u>](https://pypi.org/project/drain3/%5Breference:10%5D)

\[10\] Ollama Development Team. (2025). Revolutionizing PDF Q&Awith
local LLMs and privacy-enhanced retrieval-augmented generation. In
*2025* *International* *Conference* *on* *Artificial* *Intelligence*
*and* *Intelligent* *Information* *Processing* *(AIIIP)*. IEEE.

\[11\] LangChain Development Team. (2024). LangChain: Building
applications with LLMs. *LangChain* *Documentation*. Available at:
https://docs.langchain.com\[reference:13\]

\[12\] Siffer, A., Fouque, P. A., Termier, A., & Largouët, C. (2017).
Anomaly detection in streams with extreme value theory. In *Proceedings*
*of* *the* *23rd* *ACM* *SIGKDD* *International* *Conference* *on*
*Knowledge* *Discovery* *and* *Data* *Mining*, pp. 1067–1075. ACM.

\[13\] Chase, H. (2022). LangChain: Building applications with large
language models through composability. *GitHub* *repository*. Available

at:
[<u>https://github.com/hwchase17/langchain</u>](https://github.com/hwchase17/langchain)

\[14\] Colby, R. B., et al. (2020). Benchmarking TinyMLsystems:
Challenges and direction. In *SysML* *2020*.
